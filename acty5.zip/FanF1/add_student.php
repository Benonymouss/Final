<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

    $user_id = $_SESSION['user_id'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $last_name = $_POST['last_name'];
        $address = $_POST['address'];
        $contact_number = $_POST['contact_number'];
        $date_of_birth = $_POST['date_of_birth']; // New variable to store date of birth

        // Calculate the age of the student
        $today = date("Y-m-d");
        $dob = date("Y-m-d", strtotime($date_of_birth));
        $age = date_diff(date_create($dob), date_create($today))->y;

        // Generate a new student ID starting with 2024-XXXX
        $max_id_sql = "SELECT MAX(SUBSTRING_INDEX(student_ID, '-', -1)) AS max_id FROM students";
        $result = $conn->query($max_id_sql);
        $row = $result->fetch_assoc();
        $max_id = $row['max_id'];
        $new_id = '2024-' . str_pad(($max_id + 1), 4, '0', STR_PAD_LEFT);

        $stud_id = $new_id;

        // Check if file was uploaded without errors
        if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
            $photo_name = $_FILES['photo']['name'];
            $photo_tmp = $_FILES['photo']['tmp_name'];
            $photo_paths = 's_uploads/' . $photo_name;

            // Move uploaded file to desired directory
            if (move_uploaded_file($photo_tmp, $photo_paths)) {
                // File uploaded successfully, insert data into database
                $sql = "INSERT INTO students (student_ID, first_name, middle_name, last_name, address, contact_number, date_of_birth, age, photo_paths) 
                VALUES ('$stud_id', '$first_name', '$middle_name', '$last_name', '$address', '$contact_number', '$date_of_birth', '$age', '$photo_paths')";
                if ($conn->query($sql)) {
                    // Data inserted successfully, redirect to students.php
                    echo "<script>alert('Add Student Successfully!'); window.location.href='students.php';</script>";
                } else {
                    // Error inserting data into database
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                // Error moving uploaded file
                echo "<script>alert('Error uploading file.'); window.location.href='add_student.php';</script>";
            }
        } else {
            // No file uploaded or an error occurred
            echo "<script>alert('No file uploaded or an error occurred.'); window.location.href='add_student.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="rstyle.css">
<link rel="stylesheet" href="lstyle.css">

    <title>Add Student</title>
    <style>
    
        /* Default input outline color */
        input, textarea {
         
      
            padding: 5px;
            margin-bottom: 10px;
        }

        /* Green outline for valid inputs */
        .valid {
            border-color: green;
        }

        /* Red outline for invalid inputs */
       

        /* Disables the input field */
        input[disabled], textarea[disabled] {
            background-color: #e9ecef;
        }

        


  


        
  .container {
      background-color: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      width: 400px;
      height: 635px;
      margin-top: 10vh;
      margin-bottom: 10vh;
  }

  .photo {
border: none;
}

.form-control {
            width: 94.5%;
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 4px;
        }
    </style>
    
</head>
<body>
<div class="container">
   <h2>Add Student</h2>
<form method="POST" enctype="multipart/form-data">
    <label>First Name:</label>
    <input type="text" name="first_name" required maxlength="30"><br>
    <label>Middle Name:</label>
    <input type="text" name="middle_name" maxlength="30"><br>
    <label>Last Name:</label>
    <input type="text" name="last_name" required maxlength="30"><br>
    <label>Address:</label>
    <input type="text" name="address" maxlength="100"><br>
    <label>Contact Number:</label>
    <input type="text" name="contact_number" maxlength="11"><br>
    <label>Date of Birth:</label>
    <input type="date" name="date_of_birth" required><br>
    <label>Age:</label>
    <input type="text" name="age" maxlength="3"><br> <!-- New field to display the calculated age -->
    <label>Photo:</label>
    <input id="file-upload" type="file" class="form-control"  name="photo">
   
       
    <input type="submit" class="login-btn"  value="Add Student"> <br>

  
          
    </div>
</form>

    
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>
