<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

    $servername = "localhost";
$username = "root";
$password = "";
$dbname = "myss_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['video']) && isset($_POST['name'])) {
    $videoName = $_POST['name'];
    $videoFile = $_FILES['video'];

    if ($videoFile['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'v_uploads/';
        $uploadFile = $uploadDir . basename($videoFile['name']);
        
        // Move the uploaded file to the server
        if (move_uploaded_file($videoFile['tmp_name'], $uploadFile)) {
            // Save video information to database
            $stmt = $conn->prepare("INSERT INTO videos (name, path) VALUES (?, ?)");
            $stmt->bind_param("ss", $videoName, $uploadFile);
            $stmt->execute();
            $stmt->close();

 echo "<script>alert('The file " . htmlspecialchars($videoFile['name']) . " has been uploaded and saved.'); window.location.href='gallery.php';</script>";
        } else {
          echo "<script>alert('Failed to move uploaded file.'); window.location.href='add_video.php';</script>";
        }
    } else {
        echo "<script>alert('Error uploading file.'); window.location.href='add_video.php';</script>";
        
    }
}
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Video</title>
    <link rel="stylesheet" href="rstyle.css">
    <link rel="stylesheet" href="lstyle.css">
    <style>
    
    /* Default input outline color */
    input, textarea {
     
  
        padding: 5px;
        margin-bottom: 10px;
    }

    /* Green outline for valid inputs */
    .valid {
        border-color: green;
    }

    /* Red outline for invalid inputs */
   

    /* Disables the input field */
    input[disabled], textarea[disabled] {
        background-color: #e9ecef;
    }

    




    
.container {
  background-color: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  width: 400px;
  height: 350px;
  margin-top: 10vh;
  margin-bottom: 10vh;
}

.photo {
border: none;
}

.form-control {
        width: 94.5%;
        padding: 10px;
        border: 1px solid #e9ecef;
        border-radius: 4px;
    }
</style>
</head>
<body>
    <div class="container">
    <h2>Add Video</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="name">Video Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="video">Choose video file:</label>
        <input type="file" id="video" name="video" accept="video/*" class="form-control"  required><br><br>
      
 
  
      
        <input type="submit" value="Upload Video" class="login-btn">

      

   
    </form>
    </div>
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>
