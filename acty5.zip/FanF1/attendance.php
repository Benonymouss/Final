<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Attendance</title>
    <style>
      body{
		background-color: #f7ebfa;
		}

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #7A288A;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
          .container {
            width: 80%;
            height: auto;
            margin-left: 20vh;

            margin-top: 20vh;
          }
        .attendance-column {
            width: 30%;
        }

        .submit-btn, .summary-btn, .dashboard-btn {
            background-color: #7A288A;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

   

        .buttons-container {
            text-align: center;
            margin-top: 20px;
        }

        .buttons-container a {
            margin: 0 10px;
        }

        .dashboard-btn1 {
            background-color: #0866FF;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>



<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';
    $user_id = $_SESSION['user_id'];

    // Fetch all students
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    // Handle form submissions
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Update religion
        foreach ($_POST['religion'] as $stud_id => $status) {
            $sql = "SELECT religion FROM students WHERE student_ID=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $stud_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ($row["religion"] != $status) {
                $sql = "UPDATE students SET religion=? WHERE student_ID=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $status, $stud_id);
                $stmt->execute();
                if ($stmt->affected_rows > 0) {
                    $_SESSION['update_success'] = true;
                    ?>
                    <script>
                        alert("Update successful!");
                        window.location.href = 'attendance_summary.php';
                    </script>
                    <?php
                } else {
                    $_SESSION['update_error'] = false;
                    echo "Update failed!";
                }
            }
        }

        // Update attendance
        foreach ($_POST['attendance'] as $stud_id => $status) {
            $sql = "SELECT attendance FROM students WHERE student_ID=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $stud_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ($row["attendance"] != $status) {
                $sql = "UPDATE students SET attendance=? WHERE student_ID=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $status, $stud_id);
                $stmt->execute();
                if ($stmt->affected_rows > 0) {
                    $_SESSION['update_success'] = true;
                    ?>
                    <script>
                        alert("Update successful!");
                        window.location.href = 'attendance_summary.php';
                    </script>
                    <?php
                } else {
                    $_SESSION['update_error'] = false;
                    echo "Update failed!";
                }
            }
        }
    }

}
?>

  <div class="container">
    <h1>SUPER HUMAN INTELENCE AND AWARENESS ATTENDANCE</h1> 

    &nbsp;&nbsp; <a href="dashboard.php" class="dashboard-btn1">all</a> 
    <a href="students.php" class="dashboard-btn">Students</a>
     <a href="attendance_summary.php" class="summary-btn">Attendance Summary</a>
   

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <table border="1">
            <tr>
                <th>ID No.</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th class="attendance-column">Attendance</th>
                <th class="attendance-column">Religion</th>

            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["student_ID"]."</td>";
                    echo "<td>".$row["first_name"]."</td>";
                    echo "<td>".$row["last_name"]."</td>";
                   
                    echo "<td class='attendance-column'>";
                    echo "<select name='attendance[".$row["student_ID"]."]'>";
                    echo "<option value='Present'>Present</option>";
                    echo "<option value='Absent'>Absent</option>";
                    echo "</select>";
                    echo "</td>";

                    echo "<td class='attendance-column'>";
                    echo "<select name='religion[".$row["student_ID"]."]'>";
                    echo "<option value='SDA'>SDA</option>";
                    echo "<option value='INC'>INC</option>";
                    echo "<option value='Catholic'>Catholic</option>";
                    echo "<option value='Muslim'>Muslim</option>";
                    echo "</select>";
                    echo "</td>";
                   
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No records found</td></tr>";
            }
            ?>
        </table>
        <div class="buttons-container">
            
        
            

            <button type="submit" class="submit-btn">Submit Attendance</button>
        </div>
    </form>
  </div>
  <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>