<?php
session_start();

require('fpdf181/fpdf.php'); // Include the FPDF library

if (!isset($_SESSION['user_id'])) {
    echo "<script>
        window.alert('Please login first');
        window.location.href = 'login.php';
        </script>";
    exit; // Terminate the script after redirecting
}

include 'database.php'; // Include the database connection file

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch attendance summary
$sql = "SELECT * FROM students";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

class PDF extends FPDF
{
    // Page header
    function Header()
    {
        // Logo
        $this->Image('assets/lbrainz.png', 10, 6, 20);
        // Arial bold 15
        $this->SetFont('Arial', 'B', 20);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, 'Super Human Intelligence & Awareness', 0, 0, 'C');
        // Line break
        $this->Ln(20);
    }

   
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'MEETING AGENDA', 0, 1, 'L');

// Meeting Details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(90, 10, 'Meeting/Project Name: Project Sukonomi', 0, 0);
$pdf->Cell(90, 10, 'Time:9:00AM - 10:00AM', 0, 1);

$pdf->Cell(90, 10, 'Date of Meeting: 25/09/2024', 0, 0);
$pdf->Cell(90, 10, 'Location: Seait Gymn', 0, 1);

$pdf->Cell(90, 10, 'Meeting Facilitator: CICT DEPARTMENT.', 0, 1);

$pdf->MultiCell(0, 10, '', 0, 1); // Empty cell for objective
// Attendees
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(153, 0, 153);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, '1. Attendees', 0, 1, 'L', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 12);

// Table Header
$pdf->Cell(45, 10, 'Name', 1, 0, 'C');
$pdf->Cell(45, 10, 'Department/Division', 1, 0, 'C');
$pdf->Cell(45, 10, 'Religion', 1, 0, 'C');
$pdf->Cell(0, 10, 'Phone', 1, 1, 'C');

// Fetch and display attendees
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(45, 10, $row["last_name"] . ', ' . $row["first_name"], 1, 0, 'C');
    $pdf->Cell(45, 10, 'CICT', 1, 0, 'C');
    $pdf->Cell(45, 10, $row["religion"], 1, 0, 'C');
    $pdf->Cell(0, 10, $row["contact_number"], 1, 1, 'C');
}

$pdf->MultiCell(0, 10, '', 0, 1); // Empty cell for objective

// Meeting Agenda
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(153, 0, 153);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 10, '2. Meeting Agenda', 0, 1, 'L', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial','', 12);

// Table Header
$pdf->Cell(80, 10, 'Topic', 1, 0, 'C');
$pdf->Cell(55, 10, 'Owner', 1, 0, 'C');
$pdf->Cell(55, 10, 'Time', 1, 1, 'C');

// Table Rows
$pdf->Cell(80, 10, 'Introduction and Overview of CICT', 1, 0, 'C');
$pdf->Cell(55, 10, 'Department Head', 1, 0, 'C');
$pdf->Cell(55, 10, '9:00 AM - 9:15 AM', 1, 1, 'C');

$pdf->Cell(80, 10, 'Review of Current Projects and Initiatives', 1, 0, 'C');
$pdf->Cell(55, 10, 'Project Manager', 1, 0, 'C');
$pdf->Cell(55, 10, '9:15 AM - 9:45 AM', 1, 1, 'C');

$pdf->Cell(80, 10, 'Budget Allocation and Financial Planning', 1, 0, 'C');
$pdf->Cell(55, 10, 'Finance Officer', 1, 0, 'C');
$pdf->Cell(55, 10, '9:45 AM - 10:15 AM', 1, 1, 'C');

$pdf->Cell(80, 10, 'Cybersecurity Measures and Updates', 1, 0, 'C');
$pdf->Cell(55, 10, ' IT Security Specialist', 1, 0, 'C');
$pdf->Cell(55, 10, '10:15 AM - 10:45 AM', 1, 1, 'C');

$pdf->Cell(80, 10, 'Digital Literacy and Training Programs', 1, 0, 'C');
$pdf->Cell(55, 10, 'Training Coordinator', 1, 0, 'C');
$pdf->Cell(55, 10, '10:45 AM - 11:15 AM', 1, 1, 'C');




// Signatory Section
$pdf->Ln(5); // Minimized line spacing
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'Approved By:', 0, 1);
$pdf->SetFont('Arial', 'U', 10);
$pdf->Cell(0, 10, 'Benjamin Arcillo', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 1, 'SHIA Owner', 0, 1);

// Output PDF to browser
$pdf->Output('I', 'Attendance_Report.pdf');

?>