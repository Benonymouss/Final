<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Summary</title>
    <style>
        body {
            background-color: #f7ebfa;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #7A288A;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .print-btn, .attendance-btn, .dashboard-btn {
            background-color: #7A288A;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
            text-decoration: none;
            text-align: center;
            margin: 0 auto;
            width: fit-content;
        }

        .buttons-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .buttons-container a {
            margin: 0 10px;
        }

        .total-counts {
            text-align: center;
        }

        .dashboard-btn1 {
            background-color: #0866FF;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <?php include 'database.php'; ?>

    <?php
    // Fetch attendance summary
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    // Initialize counters for absent and present students
    $totalAbsent = 0;
    $totalPresent = 0;

    // Initialize counters for religion types
    $totalSda = 0;
    $totalInc = 0;
    $totalCatholic = 0;
    $totalMuslim = 0;

    // Count the number of absent and present students, and religion types
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($row["attendance"] == "Absent") {
                $totalAbsent++;
            } else if ($row["attendance"] == "Present") {
                $totalPresent++;
            }

            if ($row["religion"] == "Sda") {
                $totalSda++;
            }
            if ($row["religion"] == "Inc") {
                $totalInc++;
            }
            if ($row["religion"] == "Catholic") {
                $totalCatholic++;
            }
            if ($row["religion"] == "Muslim") {
                $totalMuslim++;
            }
        }
    }
    ?>

    <h1>Meeting Attendance Summary</h1>

    <table border="1">
        <tr>
            <th>Student Name</th>
            <th>Attendance Remarks</th>
            <th>Religion Remarks</th>
        </tr>
        <?php
        // Reset the pointer of the result set
        $result->data_seek(0);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";

                echo "<td>" . $row["first_name"] . " " . $row["last_name"] . "</td>";
                echo "<td>" . $row["attendance"] . "</td>";
                echo "<td>" . $row["religion"] . "</td>";

                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No attendance data found</td></tr>";
        }
        ?>
    </table>

    <p class="total-counts">Total Absent: <?php echo $totalAbsent; ?></p>
    <p class="total-counts">Total Present: <?php echo $totalPresent; ?></p>
    <br><br>

  

    <div class="buttons-container">
        <a href="dashboard.php" class="dashboard-btn1">All</a>
        <a href="students.php" class="dashboard-btn">Students</a>
        <a href="attendance.php" class="attendance-btn">Attendance Table</a>
        <button class="attendance-btn" onclick="alert('Generate Successfully'); window.open('attendance_report.php', '_blank');">Generate Attendance Report</button>
    </div>
</body>
</html>