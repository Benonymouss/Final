<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';
    $user_id = $_SESSION['user_id'];

    $sql = "SELECT name, photo_path FROM user WHERE User_id='$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $photo_path = $row['photo_path'];
    } else {
        echo "<script>alert('Error fetching user information!');</script>";
        exit();
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 <link rel="stylesheet" href="sidebar.css">
  <title>Dashboard</title>
	<style>
		
    body{
		background-color: #f7ebfa;
		}

   
    .profile-container {
    position: relative;
    width: 50px;
    height: 50px;
}
.profile-image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-image: url('<?php echo $photo_path; ?>');
    background-size: cover;
    background-position: center;
    
}

#chart-container {
  margin-left: 80vh;
  margin-top: 5vh;
}



 

	</style>
   

	


   <html>
 <head>
  <title>
   Attendance Dashboard
  </title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <style>
   body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3e5f5;
        }
        .sidenav {
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #ffffff;
            overflow-x: hidden;
            transition: 0.5s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 1);
            width: 250px;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
           
        }
        .sidenav.closed {
            width: 85px;
          
        }
        .sidenav a {
            padding: 8px 8px 8px 32px;
            font-size: 25px;
            color: #818181;
            display: flex;
            align-items: center;
            transition: 0.3s;
            text-decoration: none;
            width: 100%;
            justify-content: center;
           
        }
        .sidenav a:hover {
            color: #f1f1f1;
        }
        .closebtn {
            font-size: 24px;
            cursor: pointer;
            padding: 8px 8px 8px 32px;
            align-self: flex-start;
        }
        .profile {
            text-align: center;
            padding-top: 10vh;
            margin-left: 4vh;
            transition: opacity 0.3s, transform 0.3s;
        }
        .profile img {
            width: 150px;
            height: 150px;
            border: 2px solid #7A288A;
            transition: width 0.3s, height 0.3s;
         
        }
        .profile h2 {
            font-size: 24px;
            color: #ccc;
            margin: 10px 0;
            transition: opacity 0.3s;
        }
        .fggs {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 3vh;
            border-radius: 5px;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .fggs img {
            font-size: 24px;
            border: 2px solid #7A288A;
            width: 50px;
            height: 50px;
            border-radius: 5px;
        }
        .fggs span {
            font-size: 18px;
            transition: opacity 0.3s;
            display: flex;
            justify-content: flex-start;
            align-self: flex-start;
        }
        .sidenav.closed .profile {
            height: auto;
        }
        .sidenav.closed .profile img {
            width: 40px;
             height: 40px;
             border: none;
             border-radius: 10px;
        }
        .sidenav.closed .fggs {
            display: flex;
          
        }
        .sidenav.closed .profile h2,
        .sidenav.closed .fggs span,
        .sidenav.closed ul li a span {
      
      
            opacity: 0;
            width: 0;
            display: none;
        }
        ul {
            display: block;
            list-style-type: none;
            margin-block-start: 1em;
            margin-block-end: 2em;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            padding-inline-start: 0px;
            unicode-bidi: isolate;
            width: 100%;
        }
        ul li a {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        ul li a img {
            margin-right: 10px;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }
        .topbar {
            height: 60px;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .topbar input {
            width: 300px;
            height: 40px;
            border-radius: 20px;
            border: 1px solid #d1c4e9;
            padding: 0 20px;
            font-size: 16px;
            background-color: #f3e5f5;
        }
        .topbar .icons {
            display: flex;
            align-items: center;
        }
        .topbar .icons i {
            font-size: 20px;
            margin: 0 10px;
        }
        .topbar .icons img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.5s;
        }
        .content.collapsed {
            margin-left: 85px;
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        .tabs button {
            background-color: #7e57c2;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .tabs button.active {
            background-color: #1e88e5;
        }
        

        #religion-chart-container {
            margin-left: 50vh;
            margin-right: 50vh;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        #attendance-chart-container {
            margin-left: 50vh;
            margin-right: 50vh;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
  </style>
 </head>
 <body>
  <div class="sidenav" id="mySidenav">
   <div class="closebtn" onclick="toggleNav()">
   <img alt="Close" height="50" src="assets/1.png" width="50"/>
   </div>
   
   <div class="profile">
    <img alt="User profile picture" src="<?php echo $photo_path; ?>"/>
    <h2>
    <?php echo $name; ?>
    </h2>
   </div>
   <ul>
    <li>
     <a href="dashboard.php">
      <img alt="Home icon" height="40" src="assets/11.png" width="40"/>
      <span>Home</span>
     </a>
    </li>
    <li>
     <a href="Profile.php">
      <img alt="User icon" height="40" src="assets/student.png" width="40"/>
      <span>Profile</span>
     </a>
    </li>
    <li>
     <a href="gallery.php">
      <img alt="Gallery icon" height="40" src="assets/09.png" width="40"/>
      <span>Gallery</span>
     </a>
    </li>
    <li>
     <a href="logout.php">
      <img alt="Power icon" height="40" src="assets/log.png" width="40"/>
      <span>Logout</span>
     </a>
    </li>
   </ul>
  </div>
   
  
  <div class="topnav">
  <div class="topnav-right">

<!-- Search Bar -->
<div class="search-container">
  <input type="text" placeholder="Search">
</div>

<a href="#">
<img src="assets/9.png" alt="icon" width="40" height="40" style="border-radius: 50%">
</a>
<a href="#">
<img src="assets/5.png" alt="icon" width="40"height="40" style="border-radius: 50%">
</a>
<a href="#">
<img src="assets/3.png" alt="icon" width="40"height="40" style="border-radius: 50%">
</a>


<a href="Profile.php">
<div class="profile-container">
<div class="profile-image" alt="Profile image of a dark figure with glowing eyes"></div>

</div>
</a>


</div>

</div>

<div class="content" id="mainContent">

   
<div class="container mt-3">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">All</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="students.php">Student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
         
            <li class="nav-item">
                <a class="nav-link" href="attendance.php">Attendance</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="attendance_summary.php">Attendance Summary</a>
            </li>
         
          

        </ul>
    </div><br><br>

 </div>


 <?php
// Retrieve data from the database
$conn = mysqli_connect("localhost", "root", "", "myss_database");

// Attendance data
$sql = "SELECT attendance FROM students";
$result = mysqli_query($conn, $sql);

// Prepare the data for the attendance graph
$absent = 0;
$present = 0;

while($row = mysqli_fetch_assoc($result)) {
    if($row["attendance"] == "Absent") {
        $absent++;
    } else if($row["attendance"] == "Present") {
        $present++;
    }
}

// Create a FusionCharts-compatible data array for attendance
$attendanceChartData = array(
    "chart" => array(
        "caption" => "Attendance Graph",
        "yAxisName" => "Count",
        "theme" => "fusion"
    ),
    "data" => array(
      array("label" => "Present", "value" => $present, "color" => "#33CC33"), // Green color
      array("label" => "Absent", "value" => $absent, "color" => "#FF0000") // Red color
    )
);

// Religion data
$sql = "SELECT religion FROM students";
$result = mysqli_query($conn, $sql);

// Prepare the data for the religion graph
$religions = array();
while($row = mysqli_fetch_assoc($result)) {
    $religion = $row["religion"];
    if (!isset($religions[$religion])) {
        $religions[$religion] = 1;
    } else {
        $religions[$religion]++;
    }
}

// Create a FusionCharts-compatible data array for religion
$religionChartData = array(
    "chart" => array(
        "caption" => "Religion Graph",
        "yAxisName" => "Count",
        "theme" => "fusion"
    ),
    "data" => array()
);

foreach ($religions as $religion => $count) {
    $religionChartData["data"][] = array("label" => $religion, "value" => $count);
}

// Close the database connection
mysqli_close($conn);
?>

<!-- Include the FusionCharts library -->
<script src="https://cdn.fusioncharts.com/fusioncharts/latest/fusioncharts.js"></script>

<!-- Render the attendance chart -->
<div id="attendance-chart-container"></div>
<script>
    FusionCharts.ready(function() {
        var chart = new FusionCharts({
            type: "column2d",
            renderAt: "attendance-chart-container",
            width: "800",
            height: "400",
            dataFormat: "json",
            dataSource: <?php echo json_encode($attendanceChartData); ?>
        });
        chart.render();
    });
</script>

<!-- Render the religion chart -->
<div id="religion-chart-container"></div>
<script>
    FusionCharts.ready(function() {
        var chart = new FusionCharts({
            type: "column2d",
            renderAt: "religion-chart-container",
            width: "800",
            height: "400",
            dataFormat: "json",
            dataSource: <?php echo json_encode($religionChartData); ?>
        });
        chart.render();
    });
</script>



	<script>




   const imageInput = document.getElementById('image-input');
  const imagePreview = document.getElementById('image-preview');
  const dragDropArea = document.getElementById('drag-drop-area');
  const dragDropText = document.getElementById('drag-drop-text');

  imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      imagePreview.innerHTML = `<img src="${event.target.result}" alt="Selected Image" style="max-width: 100%; height: auto;">`;
      dragDropText.style.display = 'none';
    };

    reader.readAsDataURL(file);
  });

  dragDropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
  });

  dragDropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      const reader = new FileReader();

      reader.onload = (event) => {
        imagePreview.innerHTML = `<img src="${event.target.result}" alt="Selected Image" style="max-width: 100%; height: auto;">`;
        dragDropText.style.display = 'none';
      };

      reader.readAsDataURL(file);
    }
  });


submitBtn.addEventListener('click', (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'insert.php', true);
  xhr.onload = function() {
    if (xhr.status === 200) {
      document.getElementById('response-message').innerHTML = 'Image submitted successfully!';
    } else {
      document.getElementById('response-message').innerHTML = 'Error submitting image!';
    }
  };
  xhr.send(formData);
});

// Add an event listener to the dropdown icon
document.querySelector('.dropdown-icon').addEventListener('click', function() {
  // Toggle the show class on the popup container
  document.querySelector('.popup-container').classList.toggle('show');
});

function toggleNav() {
    var sidenav = document.getElementById('sidenav');
    sidenav.classList.toggle('closed');
}

  </script>
 
</body>
</html>

    
    
    
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
        <script src="menu.js"></script>
        <script>
   function toggleNav() {
            var sidenav = document.getElementById("mySidenav");
            var mainContent = document.getElementById("mainContent");
            sidenav.classList.toggle("closed");
            mainContent.classList.toggle("collapsed");
        }
  </script>
 </body>
</html>
