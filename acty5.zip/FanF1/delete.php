<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'database.php';

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_account'])) {
        // Fetch the current password from the database
        $sql = "SELECT password FROM user WHERE User_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Verify the password
        $password = $_POST['password'];

        if ($password === $user['password']) {
            // Password is correct, delete the account
            $sql = "DELETE FROM user WHERE User_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                session_destroy();
                header("Location: login.php");
                exit();
            } else {
                $message = "Error deleting account: " . $conn->error;
            }
        } else {
            // Password is incorrect
            $message = "Incorrect password. Account not deleted.";
        }
    }
}

$sql = "SELECT * FROM user WHERE User_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$name = $user['name'];
$photo = isset($user['photo']) ? $user['photo']: '';

$conn->close();
?>
       
  <link rel="stylesheet" href="lstyle.css">


    <div class="container">
    <h2>Delete Account ?</h2>
    <form method="post" onsubmit="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">
        
   
    <label>Enter your password to delete your account:</label><br>
    <input type="password" name="password" required><br>
    <input type="submit"  class="login-btn"      name="delete_account" value="Delete My Account">
    </form>
    </div>