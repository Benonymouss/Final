<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

    $user_id = $_SESSION['user_id'];
    $sql = "SELECT name, photo_path FROM user WHERE User_id='$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $photo_path = $row['photo_path'];
    } else {
        echo "<script>alert('Error fetching user information!');</script>";
        exit();
    }

    // Handling search query if it's submitted
    $search_query = '';
    if (isset($_GET['search'])) {
        $search_query = $_GET['search'];
        $sql = "SELECT id, name, path FROM videos WHERE id LIKE ? OR name LIKE ? OR path LIKE ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $search_query, $search_query, $search_query);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        // Fetch videos from the database
        $sql = "SELECT id, name, path FROM videos";
        $result = $conn->query($sql);
    }

    $videos = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $videos[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="sidebar.css">


    <title>Video Gallery</title>

    <style>
   body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3e5f5;
        }
        .sidenav {
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #ffffff;
            overflow-x: hidden;
            transition: 0.5s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 1);
            width: 250px;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
           
        }
        .sidenav.closed {
            width: 85px;
          
        }
        .sidenav a {
            padding: 8px 8px 8px 32px;
            font-size: 25px;
            color: #818181;
            display: flex;
            align-items: center;
            transition: 0.3s;
            text-decoration: none;
            width: 100%;
            justify-content: center;
           
        }
        .sidenav a:hover {
            color: #f1f1f1;
        }
        .closebtn {
            font-size: 24px;
            cursor: pointer;
            padding: 8px 8px 8px 32px;
            align-self: flex-start;
       
        }
        .profile {
            text-align: center;
            padding-top: 10 vh;
            margin-left: 4vh;
  
            transition: opacity 0.3s, transform 0.3s;
        }
        .profile img {
            width: 150px;
            height: 150px;
            border: 2px solid #7A288A;
            transition: width 0.3s, height 0.3s;
     
   
        }
        .profile h2 {
            font-size: 24px;
            color: #ccc;
            margin: 10px 0;
            transition: opacity 0.3s;
        }
        .fggs {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 3vh;
            border-radius: 5px;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .fggs img {
            font-size: 24px;
            border: 2px solid #7A288A;
            width: 50px;
            height: 50px;
            border-radius: 5px;
        }
        .fggs span {
            font-size: 18px;
            transition: opacity 0.3s;
            display: flex;
            justify-content: flex-start;
            align-self: flex-start;
        }
        .sidenav.closed .profile {
            height: auto;
    
        }
        .sidenav.closed .profile img {
            width: 40px;
             height: 40px;
             border: none;
             border-radius: 10px;
            
        }
        .sidenav.closed .fggs {
            display: flex;
          
        }
        .sidenav.closed .profile h2,
        .sidenav.closed .fggs span,
        .sidenav.closed ul li a span {
      
      
            opacity: 0;
            width: 0;
            display: none;
        }
        ul {
            display: block;
            list-style-type: none;
            margin-block-start: 1em;
            margin-block-end: 2em;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            padding-inline-start: 0px;
            unicode-bidi: isolate;
            width: 100%;
          
        }
        ul li a {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        ul li a img {
            margin-right: 10px;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
                   
        }
        .topbar {
            height: 60px;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .topbar input {
            width: 300px;
            height: 40px;
            border-radius: 20px;
            border: 1px solid #d1c4e9;
            padding: 0 20px;
            font-size: 16px;
            background-color: #f3e5f5;
        }
        .topbar .icons {
            display: flex;
            align-items: center;
        }
        .topbar .icons i {
            font-size: 20px;
            margin: 0 10px;
        }
        .topbar .icons img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.5s;
        }
        .content.collapsed {
            margin-left: 85px;
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        .tabs button {
            background-color: #7e57c2;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .tabs button.active {
            background-color: #1e88e5;
        }
        .chart-container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
  </style>
    
    <style>

body{
		background-color: #f7ebfa;
		}
		
        .video-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 3fr));
    gap : 30px;
    margin-left: 20vh;
    margin-right: 10vh;
    margin-bottom: 15vh;
}

.video-item {
    border: 1px solid #ccc;
    padding: 10px;
    text-align: center;
    background-color: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Add box shadow */
}

.video-item video {
    max-width: 100%;
    height: auto;
}
        .action-icons a {
            margin-right: 10px;
            text-decoration: none;
            font-size: 20px; /* Adjust size as needed */
        }
        .action-icons a:hover {
            color: #007BFF; /* Color on hover */
        }

        .profile-container {
    position: relative;
    width: 50px;
    height: 50px;
}
.profile-image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-image: url('<?php echo $photo_path; ?>');
    background-size: cover;
    background-position: center;
    
}
         

        

    
     

  .nav-item .nav-link {
  background-color: #7A288A;
  margin-left: 3vh;
  color: #ffff;

}
.nav-item .nav-link:hover {
    color: #ffff;
}

.search-container {
            display: flex;
            align-items: center;
            background-color: #f7ebfa;
            border-radius: 25px;
            padding: 5px;
            width: 500px;
            margin-right: 35vh;
            border: 0.5px solid #ccc;
        }
        .search-container input[type="text"] {
            background-color: #f7ebfa;
            border: none;
            color: black;
            font-size: 16px;
            padding: 10px;
            border-radius: 25px;
            width: 100%;
            outline: none;
        }
		
        .toolbar {
            display: flex;
            justify-content: center;
            align-items: center;
            border: none;

            background-color: #ffff;
        }
   
        .toolbar-item a {
            display: block;
            text-align: center;
            font-size: 50px;
            text-decoration: none;
            color: black;
            border: none;
    
        }
        .toolbar-item img {
            width: 30px;
            height: 30px;
            border: 2px solid #7A288A;
       
        }

  
    </style>
</head>
<body>

<div class="topnav">
    <div class="topnav-left">
    <a href="#" id="menu-icon" class="closebtn" onclick="openNav()">
  <img src="assets/2-removebg-preview (1).png" alt="icon" width="40" height="40">
  
</a>


<div class="sidenav" id="mySidenav">
   <div class="closebtn" onclick="toggleNav()">
   <img alt="Close" height="50" src="assets/1.png" width="50"/>
   </div>
   
   <div class="profile">
    <img alt="User profile picture" src="<?php echo $photo_path; ?>"/>
    <h2>
    <?php echo $name; ?>
    </h2>
   </div>
   <ul>
    <li>
     <a href="dashboard.php">
      <img alt="Home icon" height="40" src="assets/11.png" width="40"/>
      <span>Home</span>
     </a>
    </li>
    <li>
     <a href="Profile.php">
      <img alt="User icon" height="40" src="assets/student.png" width="40"/>
      <span>Profile</span>
     </a>
    </li>
    <li>
     <a href="gallery.php">
      <img alt="Gallery icon" height="40" src="assets/09.png" width="40"/>
      <span>Gallery</span>
     </a>
    </li>
    <li>
     <a href="logout.php">
      <img alt="Power icon" height="40" src="assets/log.png" width="40"/>
      <span>Logout</span>
     </a>
    </li>
   </ul>
  </div>
   

</div>

<div class="topnav-right">


     <!-- Search Bar -->
     <div class="search-container">
        <input type="text" id="searchInput" placeholder="Search">
    </div>
	
    <a href="#">
      <img src="assets/9.png" alt="icon" width="40" height="40" style="border-radius: 50%">
    </a>
    <a href="#">
      <img src="assets/5.png" alt="icon" width="40"height="40" style="border-radius: 50%">
    </a>
    <a href="#">
      <img src="assets/3.png" alt="icon" width="40"height="40" style="border-radius: 50%">
    </a>

    
  <a href="Profile.php">
  <div class="profile-container">
    <div class="profile-image" alt="Profile image of a dark figure with glowing eyes"></div>

    </div>
</a>

  
  </div>

</div>

<div class="content" id="mainContent">
<div class="container mt-3">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">All</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="students.php">Student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_video.php">add Videos</a>
            </li>
          
         
        </ul>
    </div><br><br>


	
		




    <div class="video-gallery" id="videoGallery">
        <?php if (!empty($videos)): ?>
            <?php foreach($videos as $video): ?>
                <div class="video-item" data-name="<?php echo htmlspecialchars($video['name']); ?>">
                    <h3><?php echo htmlspecialchars($video['name']); ?></h3>
                    <video controls>
                        <source src="<?php echo htmlspecialchars($video['path']); ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="action-icons">
                    <div class="toolbar">
                    <div class="toolbar-item">
    <a href="download.php?id=<?php echo $video['id']; ?>" style="color: black;" title="Download">
        <img alt="Download icon" height="20" src="assets/d_load.png" width="20"/>
    </a>
</div>
<div class="toolbar-item">
    <a href="v_update.php?id=<?php echo $video['id']; ?>" style="color: black;" title="Update">
        <img alt="Update icon" height="20" src="assets/e_dit.png" width="20"/>
    </a>
</div>
<div class="toolbar-item">
    <a href="v_delete.php?id=<?php echo $video['id']; ?>" onclick="return confirm('Are you sure you want to delete this video?');" style="color: black;" title="Delete">
        <img alt="Delete icon" height="20" src="assets/d_elete.png" width="20"/>
    </a>
</div>
                </div>
                </div>
                </div>
                 
                
            <?php endforeach; ?>
        <?php else: ?>
            <p>No videos found.</p>
        <?php endif; ?>
    </div>
    </div>


 <script>
    document.getElementById('searchInput').addEventListener('input', function() {
        var searchTerm = this.value.toLowerCase();
        var videoItems = document.querySelectorAll('.video-item');
        
        videoItems.forEach(function(item) {
            var videoName = item.getAttribute('data-name').toLowerCase();
            if (videoName.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>

    

    <?php $conn->close(); ?>
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>

<script>
      function toggleNav() {
            var sidenav = document.getElementById("mySidenav");
            var mainContent = document.getElementById("mainContent");
            sidenav.classList.toggle("closed");
            mainContent.classList.toggle("collapsed");
        }
</script>
<script src="menu.js"></script>
</body>
</html>