

  function toggleNav() {
    var sidenav = document.getElementById("mySidenav");
    var mainContent = document.getElementById("mainContent");
    sidenav.classList.toggle("closed");
    mainContent.classList.toggle("collapsed");
}