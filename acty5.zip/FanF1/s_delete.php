<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';
    $user_id = $_SESSION['user_id'];

    // Check if the 'student_ID' parameter exists in the URL
    $stud_id = isset($_GET['student_ID']) ? $_GET['student_ID'] : null;

    // If the 'student_ID' parameter does not exist, display an error message and exit
    if (!$stud_id) {
        die('Invalid ID');
    }

    // Check if the 'confirm' parameter exists in the URL and its value is 'yes'
    if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
        // Create a SQL query to delete the student with the specified ID
        $sql = "DELETE FROM students WHERE student_ID = ?";

        // Prepare the statement
        $stmt = $conn->prepare($sql);

        // Bind the parameter
        $stmt->bind_param("s", $stud_id);

        // Execute the query
        $stmt->execute();

        // Check if the query was successful
        if ($stmt->affected_rows > 0) {
            // Redirect the user to the 'students.php' page
            header("Location: students.php");
            exit();
        } else {
            die('Failed to delete student');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Student Record</title>
</head>
<body>
    <script>
        function confirmDelete() {
            var confirmDelete = confirm("Are you sure you want to delete?");
            if (confirmDelete) {
                window.location.href = 's_delete.php?student_ID=<?php echo $stud_id; ?>&confirm=yes';
            } else {
                window.location.href = 'students.php';
            }
        }
        confirmDelete();
    </script>

<script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>

