<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

    $user_id = $_SESSION['user_id'];
    $stud_id = isset($_GET['student_ID']) ? $_GET['student_ID'] : null; // Check if 'student_ID' parameter exists
    if (!$stud_id) {
        die('Invalid ID');
    }

    $sql = "SELECT * FROM students WHERE student_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $stud_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $last_name = $_POST['last_name'];
        $address = $_POST['address'];
        $contact_number = $_POST['contact_number'];
        $date_of_birth = $_POST['date_of_birth']; // New variable to store date of birth

        // Calculate the age of the student
        $today = date("Y-m-d");
        $dob = date("Y-m-d", strtotime($date_of_birth));
        $age = date_diff(date_create($dob), date_create($today))->y;

        // Check if file was uploaded without errors
        if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
            $photo_name = $_FILES['photo']['name'];
            $photo_tmp = $_FILES['photo']['tmp_name'];
            $photo_paths = 's_uploads/' . $photo_name;

            // Remove old photo from server if it exists
            $old_photo_paths = $row['photo_path'];
            if (file_exists($old_photo_paths)) {
                unlink($old_photo_paths);
            }

            // Move uploaded file to desired directory
            if (move_uploaded_file($photo_tmp, $photo_paths)) {
                // File uploaded successfully, update data in database
                $sql = "UPDATE students SET 
                first_name = ?, 
                middle_name = ?, 
                last_name = ?, 
                address = ?, 
                contact_number = ?, 
                date_of_birth = ?, 
                age = ?, 
                photo_paths = ?
                WHERE student_ID = ?";
                $stmt = $conn->prepare($sql);
               $stmt->bind_param("sssssssss", $first_name, $middle_name, $last_name, $address, $contact_number, $date_of_birth, $age, $photo_paths, $stud_id);
                $stmt->execute();
            } else {
                // Error moving uploaded file
                echo "<script>alert('Error uploading file.'); window.location.href='edit_student.php?student_ID=$stud_id';</script>";
            }
        } else {
            // No file uploaded or an error occurred
            $sql = "UPDATE students SET 
            first_name = ?, 
            middle_name = ?, 
            last_name = ?, 
            address = ?, 
            contact_number = ?, 
            date_of_birth = ?, 
            age = ?
            WHERE student_ID = ?";
            $stmt = $conn->prepare($sql);
           $stmt->bind_param("ssssssss", $first_name, $middle_name, $last_name, $address, $contact_number, $date_of_birth, $age, $stud_id);
            $stmt->execute();
        }

        if ($stmt->affected_rows > 0) {
            // Record updated successfully, redirect to students.php
            echo "<script>alert('Update Student Successfully!'); window.location.href='students.php';</script>";
        } else {
            // Error updating record
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="rstyle.css">
    <link rel="stylesheet" href="lstyle.css">
    <style>
        .form-control {
            width: 94.5%;
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Student</h2>
 <form method="POST" enctype="multipart/form-data">
     <label>Student ID:</label>
    <input type="text" name="student_ID" readonly   value="<?php echo htmlspecialchars($row['student_ID']); ?>" required><br>
    <label>First Name:</label>
    <input type="text" name="first_name" value="<?php echo htmlspecialchars($row['first_name']); ?>" required><br>
    <label>Middle Name:</label>
    <input type="text" name="middle_name" value="<?php echo htmlspecialchars($row['middle_name']); ?>" required><br>
    <label>Last Name:</label>
    <input type="text" name="last_name" value="<?php echo htmlspecialchars($row['last_name']); ?>" required><br>
    <label>Address:</label>
    <input type="text" name="address" value="<?php echo htmlspecialchars($row['address']); ?>"><br>
    <label>Contact Number:</label>
    <input type="text" name="contact_number" value="<?php echo htmlspecialchars($row['contact_number']); ?>" maxlength="11"><br>
    <label>Date of Birth:</label>
    <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($row['date_of_birth']); ?>"><br>
    <label>Age:</label>
    <input type="number" name="age" value="<?php echo htmlspecialchars($row['age']); ?>"><br>
    <label>Photo:</label>
    <input id="file-upload" type="file" class="form-control" name="photo">
    <input type="submit" value="Update Student" class="login-btn"> <br>
</form>
    </div>
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>