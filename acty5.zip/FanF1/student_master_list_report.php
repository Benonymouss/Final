<?php
session_start();

require('fpdf181/fpdf.php'); // Include the FPDF library

if (!isset($_SESSION['user_id'])) {
    echo "<script>
        window.alert('Please login first');
        window.location.href = 'login.php';
        </script>";
    exit; // Terminate the script after redirecting
}

include 'database.php'; // Include the database connection file

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch student records
$sql = "SELECT * FROM students";
$result = $conn->query($sql);

class PDF extends FPDF
{
    // Page header
function Header()
{
    // Logo
    $this->SetFont('Arial', 'B', 12);
    $width = 20; // logo width
    $x = (210 - $width) / 2; // calculate x-coordinate for centering
    $this->Image('assets/lbrainz.png', $x, 6, $width, 20);
    $this->Ln(15); // Add a line break after the logo


       $this->SetFont('Arial', '', 12);
    $this->Cell(0, 10, 'South Cotabato,1st district  ', 0, 0, 'C');
   $this->Ln(5);


      $this->SetFont('Arial', '', 12);
    $this->Cell(0, 10, 'VLE Tupi-Branch  ', 0, 0, 'C');
   $this->Ln(5);


      $this->SetFont('Arial', '', 12);
    $this->Cell(0, 10, 'VLE Year 2024-2025 ', 0, 0, 'C');
   $this->Ln(10);


    // Old English font (e.g., "Playfair Display")
    $this->SetFont('Arial', 'B', 15);
   // Title
    $this->Cell(0, 10, 'Super Human Intillegence & Awaress', 0, 0, 'C');
    // Line break
    $this->Ln(10);

    $this->SetFont('Arial', 'B', 12);
    $this->Cell(0, 10, 'Masterlist of SHIA Student in Virtual Learning Environment ', 0, 0, 'C');
   $this->Ln(10);


    $this->SetFont('Arial', 'B', 10);
    $this->Cell(0, 10, 'SHIA Tupi-Branch  ', 0, 0, 'C');
   $this->Ln(10);



}
    // Page footer
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

// Create a new PDF instance
$pdf = new PDF();
$pdf->AliasNbPages(); // Enable page numbering
$pdf->AddPage(); // Add a new page

// Header content
$pdf->SetFont('Arial', 'B', 9);

// Set fill color for all header cells
$pdf->SetFillColor(153, 0, 153);
$pdf->SetTextColor(255, 255, 255);

$pdf->Cell(20, 10, 'ID No.', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Name of Pupil/Student', 1, 0, 'C', true);
$pdf->Cell(10, 10, 'Age', 1, 0, 'C', true);
$pdf->Cell(15, 10, 'Religion', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Address', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Contact No. of Parent/Guardian', 1, 1, 'C', true);

// Reset fill color and text color
$pdf->SetFillColor(255, 255, 255); // or any other default fill color
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 12);
// Set font for data rows
$pdf->SetFont('Arial', '', 9);





// Data rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(20, 10, $row["student_ID"], 1, 0, 'C');
        $pdf->Cell(50, 10, $row["last_name"] . ', ' . $row["first_name"], 1, 0, 'L');
        $pdf->Cell(10, 10, $row["age"], 1, 0, 'C');
        $pdf->Cell(15, 10, $row["religion"], 1, 0, 'C');
        $pdf->Cell(50, 10, $row["address"], 1, 0, 'L');
        $pdf->Cell(50, 10, $row["contact_number"], 1, 1, 'L'); // New line for the next row
    }
} else {
    $pdf->Cell(0, 10, 'No records found.', 1, 1, 'C');
}

// Signatory Section
$pdf->Ln(5); // Minimized line spacing
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'Approved By:', 0, 1);
$pdf->SetFont('Arial', 'U', 10);
$pdf->Cell(0, 10, 'Benjamin Arcillo', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 1, 'SHIA Owner', 0, 1);


// Output PDF to browser
$pdf->Output('I', 'student_master_list_report.pdf'); 
?>
