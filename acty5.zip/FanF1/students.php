<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

    $user_id = $_SESSION['user_id'];
    $sql = "SELECT name, photo_path FROM user WHERE User_id='$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $photo_path = $row['photo_path'];
    } else {
        echo "<script>alert('Error fetching user information!');</script>";
        exit();
    }

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myss_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch all students
    $sql = "SELECT * FROM students"; 
    $result = $conn->query($sql); 

   if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row['name'])) {
        $first_name = $row['name'];
    } else {
        $first_name = ''; // or some default value
    }
    if (isset($row['photo_paths'])) {
        $photo_paths = $row['photo_paths'];
    } else {
        $photo_paths = ''; // or some default value
    }
} else {
    echo "<script>alert('Error fetching user information!');</script>";
}

// Handling search query if it's submitted
$search_query = '';
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
    $sql = "SELECT * FROM students WHERE first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $search_query, $search_query, $search_query);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Default SQL query to fetch all records
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="sidebar.css">

  
  <title>Student Records</title>

  <style>
   body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3e5f5;
        }
        .sidenav {
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #ffffff;
            overflow-x: hidden;
            transition: 0.5s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 1);
            width: 250px;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
           
        }
        .sidenav.closed {
            width: 85px;
          
        }
        .sidenav a {
            padding: 8px 8px 8px 32px;
            font-size: 25px;
            color: #818181;
            display: flex;
            align-items: center;
            transition: 0.3s;
            text-decoration: none;
            width: 100%;
            justify-content: center;
           
        }
        .sidenav a:hover {
            color: #f1f1f1;
        }
        .closebtn {
            font-size: 24px;
            cursor: pointer;
            padding: 8px 8px 8px 32px;
            align-self: flex-start;
       
        }
        .profile {
            text-align: center;
            padding-top: 10vh;
            padding-right: 1vh;
            transition: opacity 0.3s, transform 0.3s;
        }
        .profile img {
            width: 150px;
            height: 150px;
            border: 2px solid #7A288A;
            transition: width 0.3s, height 0.3s;
            margin-left: 3vh;
        }
        .profile h2 {
            font-size: 24px;
            color: #ccc;
            margin: 10px 0;
            transition: opacity 0.3s;
        }
        .fggs {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 3vh;
            border-radius: 5px;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .fggs img {
            font-size: 24px;
            border: 2px solid #7A288A;
            width: 50px;
            height: 50px;
            border-radius: 5px;
        }
        .fggs span {
            font-size: 18px;
            transition: opacity 0.3s;
            display: flex;
            justify-content: flex-start;
            align-self: flex-start;
        }
        .sidenav.closed .profile {
            height: auto;
        }
        .sidenav.closed .profile img {
            width: 40px;
             height: 40px;
             border: none;
             border-radius: 10px;
        }
        .sidenav.closed .fggs {
            display: flex;
          
        }
        .sidenav.closed .profile h2,
        .sidenav.closed .fggs span,
        .sidenav.closed ul li a span {
      
      
            opacity: 0;
            width: 0;
            display: none;
        }
        ul {
            display: block;
            list-style-type: none;
            margin-block-start: 1em;
            margin-block-end: 2em;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            padding-inline-start: 0px;
            unicode-bidi: isolate;
            width: 100%;
        }
        ul li a {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        ul li a img {
            margin-right: 10px;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }
        .topbar {
            height: 60px;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .topbar input {
            width: 300px;
            height: 40px;
            border-radius: 20px;
            border: 1px solid #d1c4e9;
            padding: 0 20px;
            font-size: 16px;
            background-color: #f3e5f5;
        }
        .topbar .icons {
            display: flex;
            align-items: center;
        }
        .topbar .icons i {
            font-size: 20px;
            margin: 0 10px;
        }
        .topbar .icons img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.5s;
        }
        .content.collapsed {
            margin-left: 85px;
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        .tabs button {
            background-color: #7e57c2;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .tabs button.active {
            background-color: #1e88e5;
        }
        .chart-container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
  </style>

  <style>

body{
		background-color: #f7ebfa;
		}
		
    
    .profile-container {
    position: relative;
    width: 50px;
    height: 50px;
}
.profile-image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-image: url('<?php echo $photo_path; ?>');
    background-size: cover;
    background-position: center;
    
}
         

  
  
    
  
    .icon {
    width: 20px;
    height: 20px;
    background-image: url("/Share/assets/men.png");
  }
  
 


  .nav-item .nav-link {
  background-color: #7A288A;
  margin-left: 3vh;
  color: #ffff;

}

.nav-item .nav-link:hover {
    color: #ffff;
}

/* Tables */
table {
margin-left: 3vh;
 border: 1px solid #ccc;
border-collapse: collapse;
margin-bottom: 15svh;
  font-family: 'Montserrat', sans-serif;
}

th, td {
  text-align: center;
  padding: 8px;
  border: 1px solid #ccc;
}

tr:nth-child(even){background-color: #f2f2f2}
tr:hover {background-color:#3fc7ab;}

th {
  background-color: #7A288A;
  color: white;
  border: 1px solid #ccc;
}

@media only screen and (max-width: 768px) {
    table {
      font-size: 14px;
    }
    th, td {
      padding: 5px;
    }
  }
  
  @media only screen and (max-width: 480px) {
    table {
      font-size: 12px;
    }
    th, td {
      padding: 3px;
    }
  }



.p-t-20 {
  padding-top: 20px;
}

.btn {
  line-height: 40px;
  display: inline-block;
  padding: 0 25px;
  cursor: pointer;
  font-family: "Roboto", "Arial", "Helvetica Neue", sans-serif;
  color: #fff;
  -webkit-transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  -moz-transition: all 0.4s ease;
  transition: all 0.4s ease;
  font-size: 14px;
  font-weight: 700;
}

.btn--radius {
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
}



.navli {
  text-align: center;
}



.search-container {
            display: flex;
            align-items: center;
            background-color: #f7ebfa;
            border-radius: 25px;
            padding: 5px;
            width: 500px;
            margin-right: 35vh;
            border: 0.5px solid #ccc;
        }
        .search-container input[type="text"] {
            background-color: #f7ebfa;
            border: none;
            color: black;
            font-size: 16px;
            padding: 10px;
            border-radius: 25px;
            width: 100%;
            outline: none;
        }
		

        .login-btn {
    background-color: #7A288A; /* Violet color */
    color: #fff;
    text-decoration: none;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%; /* Make the buttons take up the full width of their parent container */
    max-width: 300px; /* Set a maximum width for the buttons */
    box-shadow: 0 5px 0 #5C1A6D; /* Add a shadow to create a 3D effect */
    transition: all 0.2s ease-in-out; /* Add a transition effect */
}

.login-btn:hover {
    background-color: #8B0A8B; /* Darker violet color on hover */
    transform: translateY(-2px); /* Move the button up on hover */
    box-shadow: 0 7px 0 #5C1A6D; /* Increase the shadow on hover */
}

.login-btn:active {
    transform: translateY(2px); /* Move the button down on click */
    box-shadow: 0 3px 0 #5C1A6D; /* Decrease the shadow on click */
}

.REG {  
    
    background-color: indigo; /* Violet color */
    color: #fff;
    text-decoration: none;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 300px;
    box-shadow: 0 5px 0 indigo; /* Add a shadow to create a 3D effect */
    transition: all 0.2s ease-in-out; /* Add a transition effect */
    }
    
    .REG:hover {
    background-color: indigo; /* Darker violet color on hover */
    transform: translateY(-2px); /* Move the button up on hover */
    box-shadow: 0 7px 0 indigo; /* Increase the shadow on hover */
    }
    
    .REG:active {
    transform: translateY(2px); /* Move the button down on click */
    box-shadow: 0 3px 0 #2f005e; /* Decrease the shadow on click */
    }
    
/* Add media queries to adjust the button styles based on screen size */
@media only screen and (max-width: 768px) {
  .login-btn, .REG {
    font-size: 14px; /* Decrease the font size on smaller screens */
    padding: 8px 16px; /* Decrease the padding on smaller screens */
  }
}

@media only screen and (max-width: 480px) {
  .login-btn, .REG {
    font-size: 12px; /* Decrease the font size on even smaller screens */
    padding: 6px 12px; /* Decrease the padding on even smaller screens */
  }
}

  

  
  </style>
    </head>
  

	


<body>

<div class="topnav">
    <div class="topnav-left">
    <a href="#" id="menu-icon" class="closebtn" onclick="openNav()">
  <img src="assets/2-removebg-preview (1).png" alt="icon" width="40" height="40">
  
</a>


<div class="sidenav" id="mySidenav">
   <div class="closebtn" onclick="toggleNav()">
   <img alt="Close" height="50" src="assets/1.png" width="50"/>
   </div>
   
   <div class="profile">
    <img alt="User profile picture" src="<?php echo $photo_path; ?>"/>
    <h2>
    <?php echo $name; ?>
    </h2>
   </div>
   <ul>
    <li>
     <a href="dashboard.php">
      <img alt="Home icon" height="40" src="assets/11.png" width="40"/>
      <span>Home</span>
     </a>
    </li>
    <li>
     <a href="Profile.php">
      <img alt="User icon" height="40" src="assets/student.png" width="40"/>
      <span>Profile</span>
     </a>
    </li>
    <li>
     <a href="gallery.php">
      <img alt="Gallery icon" height="40" src="assets/09.png" width="40"/>
      <span>Gallery</span>
     </a>
    </li>
    <li>
     <a href="logout.php">
      <img alt="Power icon" height="40" src="assets/log.png" width="40"/>
      <span>Logout</span>
     </a>
    </li>
   </ul>
  </div>
   

</div>

<div class="topnav-right">

     <div class="search-container">

        <input id="searchInput" name="search" type="text" placeholder="Search">
     
  
</div>
	
    <a href="#">
      <img src="assets/9.png" alt="icon" width="40" height="40" style="border-radius: 50%">
    </a>
    <a href="#">
      <img src="assets/5.png" alt="icon" width="40"height="40" style="border-radius: 50%">
    </a>
    <a href="#">
      <img src="assets/3.png" alt="icon" width="40"height="40" style="border-radius: 50%">
    </a>

    
  <a href="Profile.php">
  <div class="profile-container">
    <div class="profile-image" alt="Profile image of a dark figure with glowing eyes"></div>

    </div>
</a>

  
  </div>

</div>


<div class="content" id="mainContent">

   
<div class="container mt-3">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">All</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="students.php">Student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_student.php">Add Students</a>
            </li>
         
           <li class="nav-item">
           <a href="student_master_list_report.php" class="nav-link" onclick="alert('Generate Successfully');">Generate Student Master List</a>
           </li>

           <li class="nav-item">
           <button onclick="printTable()" class="nav-link"  >Print Table</button>
           </li> 



        </ul>
    </div><br><br>
       
    



   <table id="myTable">
    <tr>
        <th>ID No.</th>
        <th>First Name</th>
        <th>Middle Name</th>
        <th>Last Name</th>
        <th>Address</th>
        <th>Contact Number</th>
        <th>Date of Birth</th>
        <th>Age</th>
        <th>Photo</th>
        <th>Action</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["student_ID"]."</td>";
            echo "<td>".$row["first_name"]."</td>";
            echo "<td>".$row["middle_name"]."</td>";
            echo "<td>".$row["last_name"]."</td>";
            echo "<td>".$row["address"]."</td>";
            echo "<td>".$row["contact_number"]."</td>";
            echo "<td>".date("Y-m-d", strtotime($row["date_of_birth"]))."</td>"; // Format date of birth
            echo "<td>".$row["age"]."</td>"; // Display age
            echo "<td><img src='".$row["photo_paths"]."' width='100' height='100'></td>";
            echo "<td><a href='s_update.php?student_ID=".$row["student_ID"]."' class='login-btn'>Update</a> <a href='s_delete.php?student_ID=".$row["student_ID"]."' class='REG'>Delete</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='10'>No records found</td></tr>";
    }

    ?>
</table>


     </div>

<script>
    // Function to search the table
    function searchTable() {
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();
        var rows = document.querySelectorAll('table tr:not(:first-child)');
        
        rows.forEach(function(row) {
            var cells = row.getElementsByTagName('td');
            var match = false;
            
            for (var i = 1; i < cells.length - 1; i++) { // Exclude the last column
                if (cells[i].innerText.toLowerCase().includes(searchTerm)) {
                    match = true;
                    break;
                }
            }
            
            row.style.display = match ? '' : 'none';
        });
        displaySearchRecommendations();
    }

    // Add event listener to the search input
    document.getElementById('searchInput').addEventListener('input', searchTable);

    // Display search recommendations on page load
    displaySearchRecommendations();
</script>
    <script>
function printTable() {
  var table = document.getElementById('myTable'); // add an ID to your table
  var printWindow = window.open('', '', 'height=500,width=800');
  printWindow.document.write('<html><head><title>Print Table</title>');
  printWindow.document.write('</head><body>');
  printWindow.document.write(table.outerHTML);
  printWindow.document.write('</body></html>');
  printWindow.print();
  printWindow.close();
}
</script>



<script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>

<script>
      function toggleNav() {
            var sidenav = document.getElementById("mySidenav");
            var mainContent = document.getElementById("mainContent");
            sidenav.classList.toggle("closed");
            mainContent.classList.toggle("collapsed");
        }
</script>
    <script src="menu.js"></script>
</body>
</html>