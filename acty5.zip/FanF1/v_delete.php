<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myss_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // First, get the path to delete the file from the server
    $sql = "SELECT path FROM videos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($path);
    $stmt->fetch();
    $stmt->close();

    // Delete the file from the server
    if (file_exists($path)) {
        unlink($path);
    }

    // Now delete the record from the database
    $sql = "DELETE FROM videos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {

        echo "<script>alert('Video deleted successfully.'); window.location.href='gallery.php';</script>";
    } else {
        echo "<script>alert('Error deleting video.'); window.location.href='gallery.php';</script>";
     
    }
    $stmt->close();
}
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Video</title>
    <link rel="stylesheet" href="rstyle.css">
    <link rel="stylesheet" href="lstyle.css">
</head>
<body>

</body>

<script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</html>
