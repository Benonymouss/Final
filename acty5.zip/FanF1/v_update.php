<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $pop = true;
    $Login = 'login.php';
} else {
    $pop = false;
    $Login = '';
    include 'database.php';

// This script should load the current video data, display it, and allow the user to upload a new file and/or change the name
// For simplicity, only changing the name is demonstrated here

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myss_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT name FROM videos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($name);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newName = $_POST['name'];
    $sql = "UPDATE videos SET name = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $newName, $id);
    if ($stmt->execute()) {
     
     echo "<script>alert('Video name updated successfully.'); window.location.href='gallery.php';</script>";
        
    } else {
       echo "<script>alert('Error updating video.'); window.location.href='v_update.php';</script>";
    }
    $stmt->close();
}


$conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Video</title>
    <link rel="stylesheet" href="rstyle.css">
<link rel="stylesheet" href="lstyle.css">
</head>
<body>
    <div class="container">
    <h2>Update Video</h2>
    <form action="v_update.php?id=<?php echo $id; ?>" method="POST">
        <label for="name">Video Name:</label>
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($name); ?>" required><br><br>
        <input type="submit" value="Update Video" class="login-btn"  name="submit">
    </form>
    </div>

    
    <script>
        <?php if ($pop): ?>
        window.alert("Please login first");
        window.location.href = "<?php echo $Login; ?>";
        <?php endif; ?>
    </script>
</body>
</html>
