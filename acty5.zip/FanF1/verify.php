<?php
include 'database.php';
$ERROR = "";
$CAPTCHA_ERROR = "";

// Array of CAPTCHA images and their correct answers
$captcha_images = [
    ["image" => "assets/laz.jpeg", "answer" => "Lazada"],
    ["image" => "assets/amazon.jpeg", "answer" => "Amazon"],
    ["image" => "assets/google.jpeg", "answer" => "Google"],
    ["image" => "assets/facebook.jpeg", "answer" => "Facebook"],
    ["image" => "assets/X.jpeg", "answer" => "Twitter"],
    ["image" => "assets/microsoft.jpeg", "answer" => "Microsoft"],
    ["image" => "assets/apple.jpeg", "answer" => "Apple"],
    // Add more images and answers as needed
];

// Shuffle the images to randomize the display
shuffle($captcha_images);

// Select the first image for the CAPTCHA
$selected_captcha = $captcha_images[0];

// Generate random answers including the correct one
$answers = [$selected_captcha['answer']];
while (count($answers) < 3) {
    $random_answer = $captcha_images[array_rand($captcha_images)]['answer'];
    if (!in_array($random_answer, $answers)) {
        $answers[] = $random_answer;
    }
}

// Shuffle the answers to randomize their order
shuffle($answers);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $captcha = $_POST['captcha'];

    // Check CAPTCHA
    if ($captcha == $selected_captcha['answer']) {
        echo "<script>alert('Correct CAPTCHA!');window.location.href='reset_password.php';</script>";
        exit();
    } else {
        $CAPTCHA_ERROR = "<script>alert('Incorrect CAPTCHA!');window.location.href='forgot_password.php';</script>";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verify User</title>
    <link rel="stylesheet" href="fstyle.css">
    <style>
        .h-custom {
            height: 100vh;
            position: relative;
        }
        .logo {
            position: absolute;
            top: 10px;
            left: 20px;
            max-width: 500px;
        }
    
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify</h2>
        <form method="post" >
            <div class="company-section">
                <label>What is the logo in the image?</label><br>
                <img src="<?php echo $selected_captcha['image']; ?>" alt="Logo Quiz"><br>
                <?php foreach ($answers as $answer) { ?>
                    <input type="radio" name="captcha" value="<?php echo $answer; ?>" required> <?php echo $answer; ?><br>
                <?php } ?>
                <br><br>
            </div>

            <?php if (!empty($CAPTCHA_ERROR)) { ?>
                <p class="text-danger"><?php echo $CAPTCHA_ERROR; ?></p>
            <?php } ?>

            <section>
                <input type="submit" class="login-btn" value="Continue">
            </section>
        </form>
    </div>
</body>
</html>
